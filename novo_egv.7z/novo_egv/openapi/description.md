# Introdução

Aqui você encontra todas as informações necessárias para a integração com a API do EGV.

A API de Empréstimo com Garantia de Veículo (EGV) permite realizar empréstimo pessoal usando um veículo como garantia, de uma forma simples e segura.

Nesta documentação é possível conferir em detalhes toda a jornada da esteira EGV na seção [Jornada EGV](#section/Jornada-EGV).

## Tecnologia

Nossa API foi desenvolvida seguindo os padrões de arquitetura [REST](https://www.redhat.com/pt-br/topics/api/what-is-a-rest-api).

As operações são feitas por requisições aos endpoints, de acordo com os verbos HTTP, seguindo o modelo de mensagem codificada em [JSON](https://jsonapi.org/) para as requisições.

# Releases

Confira logo abaixo as últimas alterações envolvendo a API de Empréstimo com Garantia de Veículo (EGV):

| <span style="padding: 0px 10px;">Versão</span> | Mudanças                                                                                                                                                                                                           |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `0.0.2`                                        | **Alterado** <br><li>Apresentação da estrutura dos objetos `objetoExemploA` e `objetoExemploB`. A documentação está mais detalhada e intuitiva.</li> **Removido** <br><li>Eliminação do enum `ENUM_EXEMPLO_A`</li> |
| `0.0.3`                                        | </li> **Removido** <br><li>Removido URLS antigas de DES, UAT E PRD que não estavam mais sendo utilizadas.</li>                                                                                                     |

<!--
  Abaixo segue um exemplo de como devem ser editadas as releases:

  | <span style="padding: 0px 10px;">Versão</span> | Mudanças |
  | -------|----------|
  | `0.0.2` | **Alterado** <br><li>Apresentação da estrutura dos objetos `objetoExemploA` e `objetoExemploB`. A documentação está mais detalhada e intuitiva.</li> **Removido** + <br><li>Eliminação do enum `ENUM_EXEMPLO_A`</li> |
  | `0.0.3` |</li> **Removido** <br><li>Removido URLS antigas de DES, UAT E PRD que não estavam mais sendo utilizadas.</li> |
--->

# Como começar

A API do EGV utiliza o processo de autenticação OAuth2, esse tipo de autenticação via tokens JWT requer primeiramente um `client_id` e `client_secret` com base em um app cadastrado no Developer Portal, confira a seguir os passos necessários para o sucesso da sua integração:

1. Faça o seu cadastro no nosso [Developer Portal](https://developers-sandbox.bvopen.com.br/como-comecar).

2. Com o TokenJWT obtido a partir da autenticação do seu `client_id`e `client_secret` realize a sua primeira requisição a um dos endpoints disponíveis na API!

Se tiver alguma dificuldade durante o processo de integração com a API [fale com a gente](https://developers-sandbox.bvopen.com.br/ajuda).

# Jornada EGV

Nesta seção você encontra informações de todo o fluxo da esteira EGV, desde a primeira etapa, onde ocorre a consulta de elegibilidade, até a formalização do contrato na etapa de contratação. Confira a seguir o resumo de cada uma das etapas:

1. **Verificação de elegibilidade**: etapa em que se obtém o consentimento do cliente quanto a pré-análise de crédito e ciência a respeito dos termos de uso e política de privacidade do banco BV. Além disso, também é realizada uma primeira consulta, utilizando o número do documento de identificação do cliente (CPF), em um sistema de informações de crédito (SCR), que irá indicar se o cliente está ou não elegível à liberação de crédito.

2. **Definição das características do veículo em garantia**: nesta etapa são obtidas informações sobre o veículo, como categoria, marca, modelo e versão. Além da definição das características do veículo, ao final dessa etapa é solicitado o início da simulação.

3. **Simulação**: o gatilho para o início da simulação ocorre logo após as definições das características do veículo. Ao iniciar uma simulação, são apresentadas as opções de planos de parcelamento, valor máximo aprovado para empréstimo e outras informações importantes. Nesta etapa também são disponibilizados recursos para atualizar os dados de uma simulação e prosseguir para a formalização de uma proposta (contratação).

4. **Contratação**: durante o processo de contratação ocorre a captura de dados complementares do cliente e do veículo para formalização da proposta, análise final de risco, upload de documentos, vistoria do veículo e assinatura do contrato.

## Etapa 1: verificação de elegibilidade

Nesta seção conheça os recursos disponíveis na primeira etapa da esteira de empréstimo com garantia de veículo.

[**Realize a verificação de elegibilidade**](#tag/Elegibilidade/operation/createElegibility) e inicie a jornada de empréstimo obtendo o consentimento quanto aos uso dos dados do cliente para pré-análise de crédito e ciência a respeito dos termos de uso e política de privacidade do banco BV. Com a mesma requisição realize uma primeira consulta, utilizando o número do documento de identificação do cliente (CPF), em um sistema de informações de crédito (SCR), que irá indicar se o cliente está ou não elegível à liberação de crédito.

</br>

**Recurso opcional relacionado a elegibilidade**:

[**Obtenha uma lista com histórico de elegibilidade de um cliente, por parceiro comercial**](#tag/Elegibilidade/operation/getElegibility): caso necessário você também pode obter uma lista com histórico de consultas de elegibilidade de um cliente de acordo com determinado parceiro comercial, informando os dados do cliente e do parceiro comercial responsável pelas consultas realizadas.

## Etapa 2: definição das características do veículo

Nesta etapa são obtidas informações sobre o veículo, como categoria, marca, modelo e versão. Além da definição das características do veículo, ao final dessa etapa ocorre o "gatilho" para o início da simulação.

> **Nota**\
> Observe que os recursos disponíveis nesta etapa devem ser utilizados de forma sequencial, para preencher campos, permitindo obter informações a respeito do veículo que o cliente irá utilizar como garantia. As informações obtidas sobre o veículo do cliente serão utilizadas na etapa 3, para criar uma simulação de proposta.

[**1. Obtenha as opções de categoria do veículo**](#tag/Veiculo/operation/getCategoriesV2) ao consultar a relação de categorias de veículos cadastrados no EGV, disponíveis para requisição.

[**2. Obtenha as opções de marca do veículo**](#tag/Veiculo/operation/getBrandsV2) ao consultar a relação de marcas de veículos cadastrados no EGV, filtradas conforme o `id` da categoria, obtido no endpoint anterior (passo 1).

[**3. Obtenha as opções de modelo do veículo**](#tag/Veiculo/operation/getModelsV2) ao consultar a relação de modelos de veículos cadastrados no EGV, filtrados conforme o `id` da marca, obtido no endpoint anterior (passo 2).

[**4. Obtenha as opções de versão do veículo**](#tag/Veiculo/operation/getVersionsV2) ao consultar a relação de versões de veículos cadastrados no EGV, filtradas conforme o `id` do modelo, obtido no endpoint anterior (passo 3).

> **Importante**\
> Ao projetar a jornada de experiência do usuário (cliente), é importante que a informação sobre a placa do veículo também seja obtida no mesmo momento em que são preenchidas as informações sobre as características do veículo, pois este dado será necessário [na etapa 4](#section/Jornada-EGV/Etapa-2:-definicao-das-caracteristicas-do-veiculo), ao solicitar a análise de risco (de aceitação do veículo como garantia).

Após obter o identificador único da versão do veículo (`idVersao`), você terá as informações sobre o veículo necessárias para dar início a [etapa de simulação](#section/Jornada-EGV/Etapa-3:-simulacao).

## Etapa 3: simulação

O início da simulação ocorre após obter informações sobre as características do veículo (através dos endpoints da etapa 2). Nesta etapa também são disponibilizados recursos para atualizar os dados de uma simulação e prosseguir para a formalização de uma proposta (contratação).

A jornada de simulação disponibiliza um fluxo funcional simplificado, prevendo **duas possíveis situações**, escolha uma delas e siga o passo a passo para garantir o sucesso de sua simulação de empréstimo com garantia de veículo:

- **Criar uma nova simulação**;
- **Recuperar uma simulação em andamento** (verificar recursos opcionais).

[**Crie uma simulação**](#tag/Simulacao/operation/postSimulationsV2), dando início a etapa onde você faz o envio de dados principais do cliente, do veículo em garantia e do parceiro responsável pela operação de empréstimo.

Ao iniciar uma simulação, no response da chamada são retornadas as opções de planos de parcelamento, valor máximo aprovado para empréstimo e outras informações importantes. Caso necessário você também pode optar por [alterar os dados da simulação](#tag/Simulacao/operation/patchSimulationV2), caso contrário prossiga para a etapa de contratação.

</br>

**Recursos opcionais relacionados a simulação**:

- [**Recupere uma simulação já iniciada**](#tag/Simulacao/operation/getSimulationsV2), informando o identificador da simulação (`idSimulacao`).

  Ao recuperar uma simulação, no response da chamada são retornadas as opções de planos de parcelamento, valor máximo aprovado para empréstimo e outras informações importantes. Caso necessário você também pode optar por alterar os dados da simulação, caso contrário prossiga para a etapa de contratação.

- [**Altere os dados de uma simulação**](#tag/Simulacao/operation/patchSimulationV2), informando o identificador da simulação (`idSimulacao`).

  Este recurso é especialmente útil caso seja necessário atualizar as condições de parcelamento e/ou valor da transação de empréstimo, confira mais informações verificando os dados enviados nesta requisição.

Após o cliente estar de acordo com as condições da simulação, com valor máximo aprovado e já optado por um plano de parcelamento adequado, será necessário então prosseguir para a [etapa de contratação](#section/Jornada-EGV/Etapa-4:-contratacao).

## Etapa 4: contratação

O início da etapa de contratação deve ocorrer após confirmar as condições de empréstimo, como forma de parcelamento e valor da transação (ambas definições ocorrem na etapa de simulação).

Nesta seção, será abordado o processo de contratação, onde ocorrem os seguintes eventos:

- **Criação de uma proposta**;
- **Solicitação de análise de risco** (informa placa do veículo);
- **Captura de todos os dados do cliente**;
- **Upload de documentos** (do cliente e do veículo);
- **Solicitação de vistoria do veículo**;
- **Assinatura e formalização do contrato**.
- **Análise final e pagamento**.

Confira cada um desses passos logo abaixo, em detalhes:

[**1. Solicite criar uma proposta**](#tag/Proposta/operation/postProposalV2), prosseguindo com as condições de empréstimo escolhidas durante a simulação.

</br>

[**2. Capture dados complementares do veículo**](#tag/Proposta/operation/patchPropostaVeiculo), e realize a análise de risco da aceitação do veículo como garantia. Ao realizar uma requisição ao endpoint, você informa a placa do veículo, dado complementar para realizar a análise de risco.

> **Importante**\
> Ao projetar a jornada de experiência do usuário (cliente), é importante que a informação sobre a placa do veículo já tenha sido obtida no mesmo momento em que são preenchidas as informações sobre as características do veículo ([na etapa 2](#section/Jornada-EGV/Etapa-2:-definicao-das-caracteristicas-do-veiculo)).

</br>

[**3. Capture todos os dados do cliente**](#tag/Proposta/operation/patchPropostaPessoa), necessários para viabilizar o prosseguimento de uma proposta de empréstimo com garantia de veículo.

Visando facilitar um fluxo padronizado de inserção de dados, disponibilizamos uma série de recursos para obter informações por meio de requisições aos [endpoints de domínio](#tag/Dominios):

Informações pessoais:

- [Obter opções de estado civil](#tag/Dominios/operation/getMaritalStatus);
- [Obter opções quanto ao estado da federação em que foi emitido o documento de identificação](#tag/Dominios/operation/getUf);
- [Obter gênero](#tag/Dominios/operation/getGenders);
- [Obter tipo de documento a ser informado](#tag/Dominios/operation/getDocumentTypes).

Informações sobre o endereço:

- [Obter o estado de residência](#tag/Dominios/operation/getUf);
- [Obter endereço ao informar o CEP](#tag/Dominios/operation/getAdressByZipcode);
- [Obter opções quanto ao tipo de endereço](#tag/Dominios/operation/getAddressTypes).

Informações profissionais:

- [Obter opções de profissão](#tag/Dominios/operation/getProfessions);
- [Obter opções para tipo de categoria profissional](#tag/Dominios/operation/getProfessionsCategories);
- [Obter opções de renda](#tag/Dominios/operation/getTypeIncome);
- [Obter opções quanto ao tipo de endereço](#tag/Dominios/operation/getAddressTypes);
- [Obter opções quanto ao estado da federação em que se localiza a empresa](#tag/Dominios/operation/getUf);
- [Obter endereço profissional ao informar o CEP](#tag/Dominios/operation/getAdressByZipcode).

Informações bancárias:

- [Obter opções de banco](#tag/Dominios/operation/getAllBanks);
- [Obter opções quanto ao tipo de conta](#tag/Dominios/operation/getAccountTypes).

> **Nota**\
> Ao projetar a jornada de experiência do usuário (cliente), é importante observar que o momento mais oportuno da jornada para obter todas as informações complementares do cliente, deve ocorrer mediante um fluxo padronizado de inserção de dados, parte das informações devem ser obtidas por preenchimento (exemplo: nome completo, núm. do documento de identificação, etc.), outra parte obtida realizando chamadas aos endpoints de domínio.

</br>

[**4. Realize o upload de documentos**](#tag/Proposta/operation/postProposalV2): este recurso viabiliza realizar uma chamada para obter um link utilizado para o upload de cada documento de identificação (do cliente e do veículo). **Deverá ser realizada uma requisição individual para cada documento a realizar upload**.

Como funciona o processo de validação dos documentos enviados:

- **Validação sistêmica**: é verificada a legitimidade do documento, também se não há ocorrência de malware junto ao arquivo enviado;
- **Validação manual**: ocorre ao realizar a validação pré-pagamento. A validação manual ocorre de forma esporádica, apenas em casos de inconsistência durante a validação sistêmica (automática).

Em ambos tipos de validação o integrador (você parceiro EGV) recebe via callback as inconsistências encontradas nos documentos, para tratamento e notificação de seus clientes. Identificando a necessidade de novas requisições para upload de documentos, regularização da formalização e prosseguimento do processo de pagamento.

</br>

[**5. Solicite a vistoria do veículo**](#tag/Proposta/operation/getPropostaInspecao): este recurso viabiliza realizar uma requisição para obter um link, que direciona o cliente a um serviço parceiro especialista em vistoria/inspeção veicular.

O link para vistoria é enviado via SMS para cliente (ou WhatsApp), através do número de contato informado no momento da [captura dos dados completos do cliente](#tag/Proposta/operation/patchPropostaPessoas), e tem validade de 72h após o envio.

O status do processo de vistoria é informado via callback, através de uma URL definida pelo integrador (você parceiro EGV), onde de forma assíncrona é atualizado quanto ao sucesso da vistoria e liberação para assinatura do contrato.

</br>

[**6. Solicite a assinatura do contrato**](#tag/Proposta/operation/getPropostaAssinaturaDocumento): este recurso viabiliza realizar uma chamada para obter um link, que direciona o cliente a um serviço para assinatura eletrônica do contrato.

O link para assinatura eletrônica é enviado para o e-mail informado no momento da [captura dos dados completos do cliente](#tag/Proposta/operation/patchPropostaPessoas).

O status do processo de assinatura eletrônica é informado via callback, através de uma URL definida pelo integrador (você parceiro EGV), onde de forma assíncrona é atualizado quanto ao sucesso da assinatura, dando início a análise final para execução do pagamento.

</br>

**7. Análise final e pagamento**: após análise final da consistência dos dados enviados na formalização da proposta, status de vistoria aprovada e contrato assinado com sucesso, ocorre a liberação do valor de empréstimo na conta indicada pelo cliente.

O status de pagamento efetuado é informado via callback, através de uma URL definida pelo integrador (você parceiro EGV), sinalizando o final da jornada de contratação.

</br>

**Recurso opcional relacionado a contratação**:

[**Obter dados de uma proposta**](#tag/Proposta/operation/getProposalV2): caso necessário, você também pode obter informações a respeito de uma proposta em andamento, informando o `idProposta` (mesmo `id` da simulação). Recurso especialmente útil para apresentar de forma resumida os dados de uma proposta.
